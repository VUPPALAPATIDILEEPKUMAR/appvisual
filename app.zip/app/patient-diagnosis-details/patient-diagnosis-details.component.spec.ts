import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientDiagnosisDetailsComponent } from './patient-diagnosis-details.component';

describe('PatientDiagnosisDetailsComponent', () => {
  let component: PatientDiagnosisDetailsComponent;
  let fixture: ComponentFixture<PatientDiagnosisDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PatientDiagnosisDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PatientDiagnosisDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
