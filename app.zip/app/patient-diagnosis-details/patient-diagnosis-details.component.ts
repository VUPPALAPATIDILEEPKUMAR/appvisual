import { Component, OnInit } from '@angular/core';
import { HospitalService } from '../hospital.service';
import { CheckboxRequiredValidator } from '@angular/forms';
import { Diagnosis } from '../Diagnosis';
import { Patient } from '../Patient';
import { Physician } from '../Physician';
import { Router } from '@angular/router';

@Component({
  selector: 'app-patient-diagnosis-details',
  templateUrl: './patient-diagnosis-details.component.html',
  styleUrls: ['./patient-diagnosis-details.component.css']
})
export class PatientDiagnosisDetailsComponent implements OnInit {

  patientPresent: boolean;
  physicianPresent: boolean;
  ifCard: boolean = false;
  public diagnosis: Diagnosis = new Diagnosis();
  submitted: boolean = false;
  diagnosis1: string;
  patient: Patient;
  physician: Physician;









  constructor(private hospitalService: HospitalService,private route:Router) { }



  ngOnInit(): void {



  }

  back()
    {
      this.route.navigate(['/ItemsAdmin']);
    }

  checkPatient() {
    console.log("patient checking");
    this.hospitalService.checkPatientId(this.diagnosis.patientId).
      subscribe(data => {
        this.patient = data;
        if (this.patient.id == this.diagnosis.patientId) {
          this.patientPresent = true;
        }
      },
        error => {
          console.log(error)
          this.patientPresent = false;
          console.log("in error")
        });
  }

  checkPhysician() {
    this.hospitalService.checkPhysicianId(this.diagnosis.physicianId).
      subscribe(data => {
        this.physician = data;
        console.log(data);
        if (this.physician.id == this.diagnosis.physicianId) {
          this.physicianPresent = true;
        }
      },
        error => {
          console.log(error);
          this.physicianPresent = false;
        });

  }
  newDiagnosis():void{
    this.submitted = false;
    this.diagnosis = new Diagnosis();
  }

  save() {
    console.log("hiee" + this.diagnosis);
    this.hospitalService.createDiagnosis(this.diagnosis)
      .subscribe(data => {
        console.log(data);
        this.submitted = true;
      },
        error => console.log(error));
    this.diagnosis = new Diagnosis();

  }






  onSubmit() {
    this.save();
  }




}
