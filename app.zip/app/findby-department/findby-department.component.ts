import { Component, OnInit } from '@angular/core';
import { Physician } from '../Physician';
import { NgForm } from '@angular/forms';
import { HospitalService } from '../hospital.service';

@Component({
  selector: 'app-findby-department',
  templateUrl: './findby-department.component.html',
  styleUrls: ['./findby-department.component.css']
})
export class FindbyDepartmentComponent implements OnInit {

  department1:string;
  physicians:Physician[];
  departments = ['a','b','c'];

  constructor(private hospitalService:HospitalService) { }

  ngOnInit(): void {
  }

  onSubmit()
  {
this.findPhysicians();
  }

  private findPhysicians()
  {
this.physicians = [];
this.hospitalService.getPhysiciansByDepartment(this.department1).
subscribe(physicians => this.physicians = physicians);
  }

  resetForm(departmentForm:NgForm)
  {
departmentForm.reset(); 
  }

}
