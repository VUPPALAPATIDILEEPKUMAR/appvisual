export class Patient{
    public id:number;
    public firstName:string;
    public lastName:string;
    public passWord:string;
    public dateOfBirth:Date;
    public emailId:string;
    public contactNumber:number;
    public state:string;
    public insurancePlan:string;
    
}