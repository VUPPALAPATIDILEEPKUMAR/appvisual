import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FindbyInsuranceplanComponent } from './findby-insuranceplan.component';

describe('FindbyInsuranceplanComponent', () => {
  let component: FindbyInsuranceplanComponent;
  let fixture: ComponentFixture<FindbyInsuranceplanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FindbyInsuranceplanComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FindbyInsuranceplanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
