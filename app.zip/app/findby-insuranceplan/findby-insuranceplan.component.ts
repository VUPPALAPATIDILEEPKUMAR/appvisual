import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Physician } from '../Physician';
import { HospitalService } from '../hospital.service';

@Component({
  selector: 'app-findby-insuranceplan',
  templateUrl: './findby-insuranceplan.component.html',
  styleUrls: ['./findby-insuranceplan.component.css']
})
export class FindbyInsuranceplanComponent implements OnInit {

  constructor(private hospitalService:HospitalService) { }

  insurancePlan1:string;
  physicians:Physician[];
  ngOnInit(): void {
  }

  private findPhysicians()
  {
this.physicians = [];
this.hospitalService.getPhysiciansByInsurancePlan(this.insurancePlan1).
subscribe(physicians => this.physicians = physicians);
  }

  onSubmit()
  {
this.findPhysicians();
  }

  resetForm(insurancePlanForm:NgForm)
  {
insurancePlanForm.reset();
  }

}
