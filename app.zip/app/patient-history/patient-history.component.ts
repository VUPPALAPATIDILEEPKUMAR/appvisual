import { Component, OnInit } from '@angular/core';
import { HospitalService } from '../hospital.service';
import { Diagnosis } from '../Diagnosis';
import { Patient } from '../Patient';
import { Router } from '@angular/router';

@Component({
  selector: 'app-patient-history',
  templateUrl: './patient-history.component.html',
  styleUrls: ['./patient-history.component.css']
})
export class PatientHistoryComponent implements OnInit {

  patientId:number;
  patients:Diagnosis[];
  patient:Patient;


  constructor(private hospitalService:HospitalService,private route:Router) { }

  ngOnInit(): void {
  }

  back()
    {
      this.route.navigate(['/ItemsAdmin']);
    }

  onSubmit()
  {
    this.findPatients();
  }
  findPatients()
  {
    this.patients = [];
    this.hospitalService.getPatientHistoryByPatientId(this.patientId).
    subscribe(patients => {this.patients = patients;
      console.log(patients);
    }   );

      this.hospitalService.checkPatientId(this.patientId).
      subscribe(patient=>{
        this.patient = patient;
        console.log(patient);
  })


}
}
