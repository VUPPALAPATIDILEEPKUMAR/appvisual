import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search-physician',
  templateUrl: './search-physician.component.html',
  styleUrls: ['./search-physician.component.css']
})
export class SearchPhysicianComponent implements OnInit {

  constructor(private route:Router) { }

  ngOnInit(): void {
  }

  back()
    {
      this.route.navigate(['/ItemsAdmin']);
    }

 

}
